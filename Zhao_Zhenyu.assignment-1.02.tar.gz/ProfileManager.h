#ifndef PROFILE_MANAGER
#define PROFILE_MANAGER

void CreatProfileDir();
void GetProfileDir();
void LoadProfile(MapInfo *mapInfo);
void SaveProfile(MapInfo *mapInfo);
void loadHallway(MapInfo *mapInfo);

#endif
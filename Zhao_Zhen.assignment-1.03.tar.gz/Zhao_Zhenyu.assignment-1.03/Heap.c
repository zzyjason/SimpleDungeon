

void heapConstruction(int *arr)
{

}

void heapify(int *arr, int index)
{
	
}

